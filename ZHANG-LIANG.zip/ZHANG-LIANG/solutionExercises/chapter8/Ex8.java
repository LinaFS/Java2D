package chapter8;

import javax.vecmath.*;
import java.awt.*;
import java.awt.event.*;
import javax.media.j3d.*;
import com.sun.j3d.utils.universe.*;
import com.sun.j3d.utils.geometry.*;
import chapter6.*;
import java.applet.*;
import com.sun.j3d.utils.applet.MainFrame;

public class Ex8 extends Applet {
  public static void main(String[] args) {
    new MainFrame(new Ex8(), 640, 640);
  }

  public void init() {
    // create canvas
    GraphicsConfiguration gc = SimpleUniverse.getPreferredConfiguration();
    Canvas3D cv = new Canvas3D(gc);
    setLayout(new BorderLayout());
    add(cv, BorderLayout.CENTER);
    VirtualUniverse universe = new VirtualUniverse();
    Locale locale = new Locale(universe);
    BranchGroup bg = createView(cv);
    locale.addBranchGraph(bg);
    bg = createContent();
    bg.compile();
    locale.addBranchGraph(bg);
  }

  private BranchGroup createView(Canvas3D cv) {
    BranchGroup bg = new BranchGroup();
    ViewPlatform platform = new ViewPlatform();
    bg.addChild(platform);    
    View view = new View();
    view.addCanvas3D(cv);
    view.setCompatibilityModeEnable(true);
    view.attachViewPlatform(platform);
    Transform3D projection = new Transform3D();
    projection.perspective(Math.PI/3, 1, 0.1, 10);
    view.setLeftProjection(projection);
    Transform3D viewing = new Transform3D();
    Point3d eye = new Point3d(0,0,1);
    Point3d look = new Point3d(0,0,0);
    Vector3d up = new Vector3d(0,1,0);
    viewing.lookAt(eye, look, up);
    view.setVpcToEc(viewing);
    PhysicalBody body = new PhysicalBody();
    view.setPhysicalBody(body);
    PhysicalEnvironment env = new PhysicalEnvironment();
    view.setPhysicalEnvironment(env);
    return bg;
  }
  
  private BranchGroup createContent() {
    BranchGroup root = new BranchGroup();
    //object
    Group shape = new chapter7.Axes();
    Transform3D tr = new Transform3D();
    tr.setScale(0.25);
    TransformGroup tg = new TransformGroup(tr);
    root.addChild(tg);
    tg.addChild(shape);
    BoundingSphere bounds = new BoundingSphere();
    //light and background
    Background background = new Background(1.0f, 1.0f, 1.0f);
    background.setApplicationBounds(bounds);
    root.addChild(background);
    AmbientLight light = new AmbientLight(true, new Color3f(Color.red));
    light.setInfluencingBounds(bounds);
    root.addChild(light);
    PointLight ptlight = new PointLight(new Color3f(Color.green),
        new Point3f(3f,3f,3f), new Point3f(1f,0f,0f));
    ptlight.setInfluencingBounds(bounds);
    root.addChild(ptlight);
    PointLight ptlight2 = new PointLight(new Color3f(Color.orange),
        new Point3f(-2f,2f,2f), new Point3f(1f,0f,0f));
    ptlight2.setInfluencingBounds(bounds);
    root.addChild(ptlight2);
    return root;
  }
}