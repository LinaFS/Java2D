package chapter8;

import javax.media.j3d.*;
import javax.vecmath.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Ex6 extends JApplet {
  public static void main(String[] args) {
    JFrame frame = new JFrame();
    JApplet applet = new Ex6();
    frame.getContentPane().add(applet);
    frame.setBounds(300, 200, 640, 480);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    applet.init();
    frame.setVisible(true);
  }
  
  private String[] labels = {"left", "right", "bottom", "top", "near", "far"};
  private JTextField[] inputs = new JTextField[6];
  private JTextField[][] outputs = new JTextField[4][4];

  public void init() {
    Container cp = getContentPane();
    cp.setLayout(new GridLayout(11, 4));
    for (int i = 0; i < 6; i++) {
      cp.add(new JLabel(labels[i]));
      inputs[i] = new JTextField();
      cp.add(inputs[i]);
      cp.add(new JPanel());
      cp.add(new JPanel());
    }
    JButton button = new JButton("frustum");
    cp.add(button);
    for (int j = 0; j < 3; j++) cp.add(new JPanel());
    button.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent ev) {
        Transform3D trans = new Transform3D();
        double[] v = new double[6];
        for (int i = 0; i < 6; i++) {
          v[i] = Double.parseDouble(inputs[i].getText());
        }
        trans.frustum(v[0], v[1], v[2], v[3], v[4], v[5]);
        Matrix4d mat = new Matrix4d();
        trans.get(mat);
        for (int i = 0; i < 4; i++) {
          for (int j = 0; j < 4; j++) {
            outputs[i][j].setText(mat.getElement(i,j)+ " ");
          }
        }
      }
    });
    for (int i = 0; i < 4; i++) {
      for (int j = 0; j < 4; j++) {
        outputs[i][j] = new JTextField();
        cp.add(outputs[i][j]);
      }
    }
  }    
}