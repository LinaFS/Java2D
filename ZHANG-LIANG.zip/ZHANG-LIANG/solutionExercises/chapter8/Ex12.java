package chapter8;

import javax.vecmath.*;
import java.awt.*;
import java.awt.event.*;
import javax.media.j3d.*;
import com.sun.j3d.utils.universe.*;
import com.sun.j3d.utils.geometry.*;
import com.sun.j3d.utils.picking.*;
import chapter6.*;
import java.applet.*;
import com.sun.j3d.utils.applet.MainFrame;

public class Ex12 extends Applet implements MouseListener{
  public static void main(String[] args) {
    new MainFrame(new Ex12(), 640, 480);
  }

  PickCanvas pc;

  public void init() {
    // create canvas
    GraphicsConfiguration gc = SimpleUniverse.getPreferredConfiguration();
    Canvas3D cv = new Canvas3D(gc);
    setLayout(new BorderLayout());
    add(cv, BorderLayout.CENTER);
    cv.addMouseListener(this);
    BranchGroup bg = createSceneGraph();
    bg.compile();
    pc = new PickCanvas(cv, bg);
    pc.setMode(PickTool.GEOMETRY);
    SimpleUniverse su = new SimpleUniverse(cv);
    su.getViewingPlatform().setNominalViewingTransform();
    su.addBranchGraph(bg);
  }

  private BranchGroup createSceneGraph() {
    BranchGroup root = new BranchGroup();
    Appearance lit = new Appearance();
    lit.setMaterial(new Material());
    Sphere sphere = new Sphere(0.2f, Primitive.ENABLE_GEOMETRY_PICKING |
      Primitive.GENERATE_NORMALS, lit);
    Transform3D tr = new Transform3D();
    tr.setTranslation(new Vector3f(0.5f, 0f,0f));
    TransformGroup tg = new TransformGroup(tr);
    Switch sw = new Switch();    
    sw.setCapability(Switch.ENABLE_PICK_REPORTING);
    sw.setCapability(Switch.ALLOW_SWITCH_READ);
    sw.setCapability(Switch.ALLOW_SWITCH_WRITE);
    root.addChild(tg);
    tg.addChild(sw);
    sw.addChild(sphere);
    Box cube = new Box(0.2f, 0.2f, 0.2f, Primitive.ENABLE_GEOMETRY_PICKING |
      Primitive.GENERATE_NORMALS, lit);
    sw.addChild(cube);
    sw.setWhichChild(0);
    
    sphere = new Sphere(0.2f, Primitive.ENABLE_GEOMETRY_PICKING |
      Primitive.GENERATE_NORMALS, lit);
    tr = new Transform3D();
    tr.setTranslation(new Vector3f(-0.5f, 0f, 0f));
    tg = new TransformGroup(tr);
    sw = new Switch();    
    sw.setCapability(Switch.ENABLE_PICK_REPORTING);
    sw.setCapability(Switch.ALLOW_SWITCH_READ);
    sw.setCapability(Switch.ALLOW_SWITCH_WRITE);
    root.addChild(tg);
    tg.addChild(sw);
    sw.addChild(sphere);
    cube = new Box(0.2f, 0.2f, 0.2f, Primitive.ENABLE_GEOMETRY_PICKING |
      Primitive.GENERATE_NORMALS, lit);
    sw.addChild(cube);
    sw.setWhichChild(0);
    
    BoundingSphere bounds = new BoundingSphere();
    Background background = new Background(1.0f, 1.0f, 1.0f);
    background.setApplicationBounds(bounds);
    root.addChild(background);
    AmbientLight light = new AmbientLight(true, new Color3f(Color.red));
    light.setInfluencingBounds(bounds);
    root.addChild(light);
    PointLight ptlight = new PointLight(new Color3f(Color.green), 
      new Point3f(3f,3f,3f), new Point3f(1f,0f,0f));
    ptlight.setInfluencingBounds(bounds);
    root.addChild(ptlight);
    PointLight ptlight2 = new PointLight(new Color3f(Color.orange), 
      new Point3f(-2f,2f,2f), new Point3f(1f,0f,0f));
    ptlight2.setInfluencingBounds(bounds);
    root.addChild(ptlight2);
    return root;
  }

  public void mouseClicked(java.awt.event.MouseEvent mouseEvent) {
    pc.setShapeLocation(mouseEvent);
    PickResult result = pc.pickClosest();
    if (result != null) {
      Switch sw = (Switch)(result.getNode(PickResult.SWITCH));
      if (sw != null) {
        sw.setWhichChild(1-sw.getWhichChild());
        System.out.println(result.toString());
      }
    }
  }

  public void mouseEntered(java.awt.event.MouseEvent mouseEvent) {
  }

  public void mouseExited(java.awt.event.MouseEvent mouseEvent) {
  }

  public void mousePressed(java.awt.event.MouseEvent mouseEvent) {
  }

  public void mouseReleased(java.awt.event.MouseEvent mouseEvent) {
  }
}