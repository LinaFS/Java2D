package chapter8;

import javax.media.j3d.*;
import javax.vecmath.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Ex4 extends JApplet {
  public static void main(String[] args) {
    JFrame frame = new JFrame();
    JApplet applet = new Ex4();
    frame.getContentPane().add(applet);
    frame.setBounds(300, 200, 640, 480);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    applet.init();
    frame.setVisible(true);
  }
  
  private String[] labels = {"eye", "look", "up"};
  private JTextField[][] inputs = new JTextField[3][3];
  private JTextField[][] outputs = new JTextField[4][4];

  public void init() {
    Container cp = getContentPane();
    cp.setLayout(new GridLayout(8, 4));
    for (int i = 0; i < 3; i++) {
      cp.add(new JLabel(labels[i]));
      for (int j = 0; j < 3; j++) {
        inputs[i][j] = new JTextField();
        cp.add(inputs[i][j]);
      }
    }
    JButton button = new JButton("lookAt");
    cp.add(button);
    for (int j = 0; j < 3; j++) cp.add(new JPanel());
    button.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent ev) {
        Transform3D trans = new Transform3D();
        double[][] v = new double[3][3];
        for (int i = 0; i < 3; i++) {
          for (int j = 0; j < 3; j++) {
            v[i][j] = Double.parseDouble(inputs[i][j].getText());
          }
        }
        Point3d eye = new Point3d(v[0][0], v[0][1], v[0][2]);
        Point3d look = new Point3d(v[1][0], v[1][1], v[1][2]);
        Vector3d up = new Vector3d(v[2][0], v[2][1], v[2][2]);
        trans.lookAt(eye, look, up);        
        Matrix4d mat = new Matrix4d();
        trans.get(mat);
        for (int i = 0; i < 4; i++) {
          for (int j = 0; j < 4; j++) {
            outputs[i][j].setText(mat.getElement(i,j)+ " ");
          }
        }
      }
    });
    for (int i = 0; i < 4; i++) {
      for (int j = 0; j < 4; j++) {
        outputs[i][j] = new JTextField();
        cp.add(outputs[i][j]);
      }
    }
  }    
}