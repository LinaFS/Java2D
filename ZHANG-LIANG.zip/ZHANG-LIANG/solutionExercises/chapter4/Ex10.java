
package chapter4;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Ex10 extends JApplet {
  public static void main(String s[]) {
    JFrame frame = new JFrame();
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JApplet applet = new Ex10();
    applet.init();
    frame.getContentPane().add(applet);
    frame.pack();
    frame.setVisible(true);
  }
  
  public void init() {
    JPanel panel = new FanPanel();
    getContentPane().add(panel);
  }
}

class FanPanel extends JPanel implements ActionListener{
    int angle = 0;
    
    public FanPanel() {
        setPreferredSize(new Dimension(400, 400));
        Timer timer = new Timer(50, this);
        timer.start();
    }

    protected void paintComponent(java.awt.Graphics g) {
        super.paintComponent(g);
        
        int xCenter = getSize().width / 2;
        int yCenter = getSize().height / 2;
        int radius = (int)(Math.min(xCenter, yCenter)*0.8)-10;
        int x = xCenter - radius;
        int y = yCenter - radius;
        
        g.setColor(Color.blue);
        g.drawOval(x-10, y-10, 2*radius+20, 2*radius+20);
        g.setColor(Color.red);
        g.fillArc(x, y, 2*radius, 2*radius, angle, 30);
        g.fillArc(x, y, 2*radius, 2*radius, angle+90, 30);
        g.fillArc(x, y, 2*radius, 2*radius, angle+180, 30);
        g.fillArc(x, y, 2*radius, 2*radius, angle+270, 30);
    }    

    public void actionPerformed(ActionEvent actionEvent) {
        angle += 10;
        if (angle > 360) angle -= 360;
        repaint();
    }    
}
