
package chapter4;

import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import java.util.Calendar;
import javax.swing.*;

public class Ex12 extends JApplet {
  public static void main(String s[]) {
    JFrame frame = new JFrame();
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JApplet applet = new Ex12();
    applet.init();
    frame.getContentPane().add(applet);
    frame.pack();
    frame.setVisible(true);
  }
  
  public void init() {
    JPanel panel = new Ex12Panel();
    getContentPane().add(panel);
  }
}

class Ex12Panel extends JPanel implements ActionListener{
  AffineTransform rotH = new AffineTransform();
  AffineTransform rotM = new AffineTransform();
  AffineTransform rotS = new AffineTransform();
  int mode = 0;
  Timer timer = new Timer(100, this);
  int hour;
  int min;
  int sec;
  int tsec;
  
  public Ex12Panel() {
    setPreferredSize(new Dimension(480, 480));
    setBackground(Color.white);
    this.addMouseListener(new MouseAdapter() {
      public void mouseClicked(MouseEvent ev) {
        switch (mode) {
            case 0:
              timer.start();
              break;
            case 1:
              timer.stop();
              break;
            case 2:
              hour = min = sec = tsec = 0;
              rotH.setToIdentity();
              rotM.setToIdentity();
              rotS.setToIdentity();
              break;
        }
        mode = (mode + 1) % 3;
        repaint();
      }
    });
  }
  
  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2 = (Graphics2D)g;
    g2.translate(240,240);
    // clock face
    Paint paint = new GradientPaint(-150,-150,Color.white,150,150,Color.gray);
    g2.setPaint(paint);
    g2.fillOval(-190, -190, 380, 380);
    g2.setColor(Color.gray);
    g2.drawString("Java 2D", -20, 80);
    Stroke stroke = new BasicStroke(3);
    g2.setStroke(stroke);
    g2.drawOval(-190, -190, 380, 380);
    for (int i = 0; i < 12; i++) {
      g2.rotate(2*Math.PI/12);
      g2.fill3DRect(-3, -180, 6, 30, true);
    }
    // clock hands
    Shape hour = new Line2D.Double(0, 0, 0, -80);
    hour = rotH.createTransformedShape(hour);
    Shape minute = new Line2D.Double(0, 0, 0, -120);
    minute = rotM.createTransformedShape(minute);
    Shape second = new Line2D.Double(0, 0, 0, -120);
    second = rotS.createTransformedShape(second);
    g2.setColor(Color.black);
    g2.setStroke(new BasicStroke(5, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
    g2.draw(hour);
    g2.draw(minute);
    g2.setStroke(new BasicStroke(2));
    g2.draw(second);
  }
  
  public void actionPerformed(ActionEvent e) {
    tsec++;
    if (tsec >= 10) {
        tsec = 0;
        sec++;
        if (sec >= 60) {
            sec = 0;
            min++;
            if (min >= 60) {
                min = 0;
                hour++;
            }
        }
    }
    rotH.setToRotation(Math.PI * (hour+min/60.0)/6.0);
    rotM.setToRotation(Math.PI * (min + sec/60.0) /30.0);
    rotS.setToRotation(Math.PI * (sec + 0.1*tsec) /30.0);
    repaint();
  }
}
