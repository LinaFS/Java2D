package chapter4;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.geom.*;

public class Ex4 extends JApplet {
  public static void main(String s[]) {
    JFrame frame = new JFrame();
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JApplet applet = new Ex4();
    applet.init();
    frame.getContentPane().add(applet);
    frame.pack();
    frame.setVisible(true);
  }
  
  public void init() {
    JPanel panel = new JPanel() {
      public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Shape t = new Ngon(17);
        g.translate(200, 200);
        ((Graphics2D)g).draw(t);
      }
    };
    panel.setBackground(Color.white);
    panel.setPreferredSize(new Dimension(400,400));
    getContentPane().add(panel);
  }
}

class Ngon implements Shape {
  GeneralPath path;

  public Ngon(Point[] vertices) {
    setPath(vertices);
  }
  
  public void setPath(Point[] vertices) {
    path = new GeneralPath();
    path.moveTo(vertices[0].x, vertices[0].y);
    for (int i = 1; i < vertices.length; i++) {
      path.lineTo(vertices[i].x, vertices[i].y);
    }
    path.closePath();
  }
  
  public Ngon(int n) {
    Point[] vert = new Point[n];
    for (int i = 0; i < n; i++) {
        vert[i] = new Point((int)(200*Math.cos(i*2*Math.PI/n)),
                (int)(200*Math.sin(i*2*Math.PI/n)));
    }
    setPath(vert);
  }

  public boolean contains(Rectangle2D rect) {
    return path.contains(rect);
  }

  public boolean contains(Point2D point) {
    return path.contains(point);
  }

  public boolean contains(double x, double y) {
    return path.contains(x, y);
  }

  public boolean contains(double x, double y, double w, double h) {
    return path.contains(x, y, w, h);
  }

  public Rectangle getBounds() {
    return path.getBounds();
  }

  public Rectangle2D getBounds2D() {
    return path.getBounds2D();
  }

  public PathIterator getPathIterator(AffineTransform at) {
    return path.getPathIterator(at);
  }

  public PathIterator getPathIterator(AffineTransform at, double flatness) {
    return path.getPathIterator(at, flatness);
  }

  public boolean intersects(Rectangle2D rect) {
    return path.intersects(rect);
  }

  public boolean intersects(double x, double y, double w, double h) {
    return path.intersects(x, y, w, h);
  }
}
