package chapter5;

import java.awt.*;
import java.applet.*;
import java.awt.event.*;
import javax.media.j3d.*;
import javax.vecmath.*;
import com.sun.j3d.utils.universe.*;
import com.sun.j3d.utils.geometry.*;
import com.sun.j3d.utils.applet.MainFrame;

public class Ex4 extends Applet {
  public static void main(String s[]) {
    new MainFrame(new Ex4(), 640, 480);
  }
  
  public void init() {
    GraphicsConfiguration gc = SimpleUniverse.getPreferredConfiguration();
    Canvas3D cv = new Canvas3D(gc);
    setLayout(new BorderLayout());
    add(cv, BorderLayout.CENTER);
    BranchGroup bg = createSceneGraph();
    bg.compile();
    SimpleUniverse su = new SimpleUniverse(cv);
    su.getViewingPlatform().setNominalViewingTransform();
    su.addBranchGraph(bg);
  }

  private BranchGroup createSceneGraph() {
    BranchGroup root = new BranchGroup();
    //object
    Shape3D shape = new ColorCube(0.3);
    //transformation
    Transform3D tr = new Transform3D();
    tr.setRotation(new AxisAngle4d(1, 1, 1, Math.PI/4));
    TransformGroup tg = new TransformGroup(tr);
    root.addChild(tg);
    tg.addChild(shape);
    //bounding leaf
    BoundingSphere bounds = new BoundingSphere();
    BoundingLeaf leaf = new BoundingLeaf(bounds);
    root.addChild(leaf);
    //background
    Background background = new Background(0.5f, 0.5f, 1.0f);
    background.setApplicationBoundingLeaf(leaf);
    root.addChild(background);
    return root;
  }
}