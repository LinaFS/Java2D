
package chapter11;

import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.imageio.*;
import com.sun.j3d.utils.geometry.*;
import com.sun.j3d.utils.behaviors.vp.*;
import com.sun.j3d.utils.universe.*;
import javax.media.j3d.*;
import javax.vecmath.*;
import java.io.*;
import java.net.*;
import com.sun.j3d.utils.image.*;
import java.applet.*;
import com.sun.j3d.utils.applet.MainFrame;

public class Ex6 extends Applet {
  public static void main(String[] args) {
    new MainFrame(new Ex6(), 480, 480);
  }

  public void init() {
    // create canvas
    GraphicsConfiguration gc = SimpleUniverse.getPreferredConfiguration();
    Canvas3D cv = new Canvas3D(gc);
    setLayout(new BorderLayout());
    add(cv, BorderLayout.CENTER);
    BranchGroup bg = createSceneGraph();
    bg.compile();
    SimpleUniverse su = new SimpleUniverse(cv);
    ViewingPlatform viewingPlatform = su.getViewingPlatform();
    viewingPlatform.setNominalViewingTransform();
    // orbit behavior to zoom and rotate the view
    OrbitBehavior orbit = new OrbitBehavior(cv,
      OrbitBehavior.REVERSE_ZOOM |
      OrbitBehavior.REVERSE_ROTATE |
      OrbitBehavior.DISABLE_TRANSLATE);
    BoundingSphere bounds =
      new BoundingSphere(new Point3d(0.0, 0.0, 0.0), 100.0);
    orbit.setSchedulingBounds(bounds);
    viewingPlatform.setViewPlatformBehavior(orbit);
    su.addBranchGraph(bg);
  }
  
  public BranchGroup createSceneGraph() {
    BranchGroup objRoot = new BranchGroup();    
    //transformation
    Transform3D trans = new Transform3D();
    trans.setTranslation(new Vector3f(-1f, -0.2f, 0f));
    TransformGroup objTrans = new TransformGroup(trans);
    objRoot.addChild(objTrans); 
    // a switch to hold the different levels
    Switch sw = new Switch(0);
    sw.setCapability(javax.media.j3d.Switch.ALLOW_SWITCH_READ);
    sw.setCapability(javax.media.j3d.Switch.ALLOW_SWITCH_WRITE);
    objTrans.addChild(sw);
    // 3 levels
    Font3D font = new Font3D(new Font("SansSerif", Font.PLAIN, 1),
                             new FontExtrusion());
    Text3D text = new Text3D(font, "Java");
    Appearance ap = new Appearance();
    ap.setMaterial(new Material());
    Shape3D shape = new Shape3D(text, ap);
    sw.addChild(shape);
    ap = new Appearance();
    ColoringAttributes ca = new ColoringAttributes();
    ca.setColor(0f, .5f, .5f);
    ap.setColoringAttributes(ca);
    ap.setMaterial(null);
    shape = new Shape3D(text, ap);
    sw.addChild(shape);
    Transform3D tr = new Transform3D();
    tr.setTranslation(new Vector3f(1f, 0.3f, 0f));
    TransformGroup tg = new TransformGroup(tr);
    sw.addChild(tg);
    tg.addChild(new Box(1f, 0.3f, 0.1f, ap));
    // the DistanceLOD behavior
    float[] distances = new float[2];
    distances[0] = 5.0f;
    distances[1] = 10.0f;
    DistanceLOD lod = new DistanceLOD(distances);
    lod.addSwitch(sw);
    BoundingSphere bounds =
    new BoundingSphere(new Point3d(0.0,0.0,0.0), 10.0);
    lod.setSchedulingBounds(bounds);
    objTrans.addChild(lod);
    //background and light
    Background background = new Background(1.0f, 1.0f, 1.0f);
    background.setApplicationBounds(bounds);
    objRoot.addChild(background);
    AmbientLight light = new AmbientLight(true, new Color3f(Color.red));
    light.setInfluencingBounds(bounds);
    objRoot.addChild(light);
    PointLight ptlight = new PointLight(new Color3f(Color.cyan),
      new Point3f(3f,3f,3f), new Point3f(1f,0f,0f));
    ptlight.setInfluencingBounds(bounds);
    objRoot.addChild(ptlight);
    return objRoot;
  }
}
