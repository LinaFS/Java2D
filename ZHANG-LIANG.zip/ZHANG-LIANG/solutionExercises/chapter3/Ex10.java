package chapter3;

import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;

public class Ex10 extends JPanel{
  
  public static void main(String args[]) {
    JFrame frame = new JFrame();
    JPanel panel = new Ex10();
    frame.getContentPane().add(panel);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.pack();
    frame.setVisible(true);
  }

  public Ex10() {
    setPreferredSize(new Dimension(640, 640));
  }

  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2 = (Graphics2D)g;
    Font font = new Font("Serif", Font.BOLD, 100);
    g2.setFont(font);
    AffineTransform tr = new AffineTransform();
    tr.translate(300, 300);
    tr.rotate(-Math.PI / 7.0);
    tr.translate(-300,-300);
    int x = 280;
    int y = 500;
    String s = "Java Graphics";
    for (int i = 0; i < s.length(); i++) {
    g2.drawString(s.substring(i,i+1), x, y);
    g2.transform(tr);
    }
  }
}
