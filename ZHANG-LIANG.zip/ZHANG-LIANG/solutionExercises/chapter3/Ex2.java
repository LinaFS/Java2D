
package chapter3;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.geom.*;

public class Ex2 extends JApplet {
  public static void main(String s[]) {
    JFrame frame = new JFrame();
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JApplet applet = new Ex2();
    applet.init();
    frame.getContentPane().add(applet);
    frame.pack();
    frame.setVisible(true);
  }
  
  public void init() {
    JPanel panel = new Ex2Panel();
    getContentPane().add(panel);
  }
}

class Ex2Panel extends JPanel{          
  public Ex2Panel() {
    setPreferredSize(new Dimension(400, 400));
    setBackground(Color.white);
  }

  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2 = (Graphics2D)g;
    int w = this.getWidth();
    int h = this.getHeight();
    int r = Math.min(w, h) - 100;
    Area a = new Area(new Rectangle(r, r));
    a.subtract(new Area(new Ellipse2D.Double(r/4, r/4, r/2, r/2)));
    g2.translate((w-r)/2, (h-r)/2);
    g2.setColor(Color.green);
    g2.fill(a);
    g2.setColor(Color.black);
    g2.draw(a);
  }
}

