
package chapter3;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.geom.*;

public class Ex14 extends JApplet {
  public static void main(String s[]) {
    JFrame frame = new JFrame();
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JApplet applet = new Ex14();
    applet.init();
    frame.getContentPane().add(applet);
    frame.pack();
    frame.setVisible(true);
  }
  
  public void init() {
    JPanel panel = new Ex14Panel();
    getContentPane().add(panel);
  }
}

class Ex14Panel extends JPanel{          
  public Ex14Panel() {
    setPreferredSize(new Dimension(400, 400));
    setBackground(Color.white);
  }

  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2 = (Graphics2D)g;
    int w = this.getWidth();
    int h = this.getHeight();
    int r = Math.min(w, h);
    Font font = new Font("SanSerif", Font.BOLD,  r/4);
    AffineTransform tx = new AffineTransform();
    tx.rotate(Math.PI/4);
    font = font.deriveFont(tx);
    g2.setFont(font);
    g2.drawString("Java 2D", 0, h/6);
  }
}
