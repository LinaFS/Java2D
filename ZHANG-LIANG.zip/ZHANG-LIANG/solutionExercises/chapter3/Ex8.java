
package chapter3;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.geom.*;

public class Ex8 extends JApplet {
  public static void main(String s[]) {
    JFrame frame = new JFrame();
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JApplet applet = new Ex8();
    applet.init();
    frame.getContentPane().add(applet);
    frame.pack();
    frame.setVisible(true);
  }
  
  public void init() {
    JPanel panel = new Ex8Panel();
    getContentPane().add(panel);
  }
}

class Ex8Panel extends JPanel {
  public Ex8Panel() {
    setPreferredSize(new Dimension(400, 400));
    setBackground(Color.white);
  }

  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2 = (Graphics2D)g;
    Font font = new Font("Serif", Font.BOLD, 48);
    g2.setFont(font);
    g2.scale(-1, 1);
    g2.drawString("Hello 2D", -300, 200);
  }
}