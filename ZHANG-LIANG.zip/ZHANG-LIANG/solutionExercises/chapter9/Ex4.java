package chapter9;

import javax.vecmath.*;
import java.awt.*;
import java.awt.event.*;
import javax.media.j3d.*;
import com.sun.j3d.utils.universe.*;
import com.sun.j3d.utils.geometry.*;
import java.applet.*;
import com.sun.j3d.utils.applet.MainFrame;

public class Ex4 extends Applet {
  public static void main(String[] args) {
    new MainFrame(new Ex4(), 640, 480);
  }

  public void init() {
    // create canvas
    GraphicsConfiguration gc = SimpleUniverse.getPreferredConfiguration();
    Canvas3D cv = new Canvas3D(gc);
    setLayout(new BorderLayout());
    add(cv, BorderLayout.CENTER);
    BranchGroup bg = createSceneGraph();
    bg.compile();
    SimpleUniverse su = new SimpleUniverse(cv);
    su.getViewingPlatform().setNominalViewingTransform();
    su.addBranchGraph(bg);
  }

  private BranchGroup createSceneGraph() {
    BranchGroup root = new BranchGroup();
    //object
    QuadArray geom = new QuadArray(4, GeometryArray.COORDINATES|GeometryArray.NORMALS);
    Point3f[] coords = {new Point3f(-1,-0.5f,0), new Point3f(1,-0.5f,0), new Point3f(1,-0.5f,-10), new Point3f(-1,-0.5f,-10)};
    geom.setCoordinates(0, coords);
    Vector3f normal = new Vector3f(0, 1, 0);
    for (int i = 0; i < 4; i++) geom.setNormal(i, normal);
    Appearance appear = new Appearance();
    Material material = new Material();
    appear.setMaterial(material);
    Shape3D shape = new Shape3D(geom, appear);
    root.addChild(shape);
    //lights
    BoundingSphere bounds = new BoundingSphere(new Point3d(), Double.MAX_VALUE);
    Background background = new Background(.6f, .6f, .6f);
    background.setApplicationBounds(bounds);
    root.addChild(background);
    DirectionalLight dLight = new DirectionalLight(new Color3f(Color.white), new Vector3f(1f,0f,-1f));
    dLight.setInfluencingBounds(bounds);
    root.addChild(dLight);
    //fog
    LinearFog fog = new LinearFog(.6f, .6f, .6f, 2f, 4f);
    fog.setInfluencingBounds(bounds);
    root.addChild(fog);
    return root;
  }
}

