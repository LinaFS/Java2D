package chapter9;

import javax.vecmath.*;
import java.awt.*;
import java.awt.geom.*;
import java.awt.image.*;
import java.net.URL;
import java.util.*;
import java.awt.event.*;
import javax.media.j3d.*;
import com.sun.j3d.utils.universe.*;
import com.sun.j3d.utils.geometry.*;
import com.sun.j3d.utils.image.*;
import java.applet.*;
import com.sun.j3d.utils.applet.MainFrame;
import com.sun.j3d.utils.behaviors.mouse.*;

public class Ex10 extends Applet {
  public static void main(String[] args) {
    new MainFrame(new Ex10(), 640, 480);
  }
  
  public void init() {
    // create canvas
    GraphicsConfiguration gc = SimpleUniverse.getPreferredConfiguration();
    Canvas3D cv = new Canvas3D(gc);
    setLayout(new BorderLayout());
    add(cv, BorderLayout.CENTER);
    BranchGroup bg = createSceneGraph();
    bg.compile();
    SimpleUniverse su = new SimpleUniverse(cv);
    su.getViewingPlatform().setNominalViewingTransform();
    su.addBranchGraph(bg);
  }
  
  private BranchGroup createSceneGraph() {
    BranchGroup root = new BranchGroup();
    TransformGroup spin = new TransformGroup();
    spin.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
    spin.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
    root.addChild(spin);
    //transform
    Transform3D tr = new Transform3D();
    tr.setScale(0.3);
    tr.setRotation(new AxisAngle4d(0, 0, 1, Math.PI/12));
    TransformGroup tg = new TransformGroup(tr);
    spin.addChild(tg);    
    //object
    Geometry geom = createGeometry();
    Appearance ap = createTextureAppearance();
    PolygonAttributes pa = new PolygonAttributes(PolygonAttributes.POLYGON_FILL,
    PolygonAttributes.CULL_NONE,0);
    pa.setBackFaceNormalFlip(true);
    ap.setPolygonAttributes(pa);
    Shape3D shape = new Shape3D(geom, ap);
    tg.addChild(shape);
    //rotator
    Alpha alpha = new Alpha(-1, 6000);
    RotationInterpolator rotator = new RotationInterpolator(alpha, spin);
    BoundingSphere bounds = new BoundingSphere();
    rotator.setSchedulingBounds(bounds);
    spin.addChild(rotator); 
    //background
    Background background = new Background(1.0f, 1.0f, 1.0f);
    background.setApplicationBounds(bounds);
    root.addChild(background);
    return root;
  }
  
  Geometry createGeometry() {
    IndexedQuadArray qa = new IndexedQuadArray(12, QuadArray.COORDINATES, 24);  
    Point3f[] coords = {new Point3f(-1,-1,-1),new Point3f(1,-1,-1),
    new Point3f(1,1,-1),new Point3f(-1,1,-1),
    new Point3f(-1,-1,1),new Point3f(1,-1,1),
    new Point3f(1,1,1),new Point3f(-1,1,1)};
    int[] coordIndices = {0,1,2,3, 0,1,5,4, 1,2,6,5, 2,3,7,6, 3,0,4,7, 4,5,6,7};
    qa.setCoordinates(0, coords);
    qa.setCoordinateIndices(0, coordIndices);
    return qa;
  }
  
  Appearance createTextureAppearance(){
    Appearance ap = new Appearance();
    BufferedImage[] bi = new BufferedImage[6];
    for (int i = 0; i < 6; i++) {
        bi[i] = new BufferedImage(128, 128, BufferedImage.TYPE_INT_ARGB);
    }
    Graphics2D g2 = (Graphics2D)bi[0].getGraphics();
    g2.setColor(Color.lightGray);
    g2.fillRect(0, 0, 128, 128);
    g2.setColor(Color.black);
    g2.fillOval(49, 49, 30, 30);
    g2 = (Graphics2D)bi[1].getGraphics();
    g2.setColor(Color.lightGray);
    g2.fillRect(0, 0, 128, 128);
    g2.setColor(Color.black);
    g2.fillOval(24, 24, 30, 30);
    g2.fillOval(74, 74, 30, 30);
    g2 = (Graphics2D)bi[2].getGraphics();
    g2.setColor(Color.lightGray);
    g2.fillRect(0, 0, 128, 128);
    g2.setColor(Color.black);
    g2.fillOval(14, 14, 30, 30);
    g2.fillOval(49, 49, 30, 30);
    g2.fillOval(84, 84, 30, 30);
    g2 = (Graphics2D)bi[3].getGraphics();
    g2.setColor(Color.lightGray);
    g2.fillRect(0, 0, 128, 128);
    g2.setColor(Color.black);
    g2.fillOval(24, 24, 30, 30);
    g2.fillOval(74, 24, 30, 30);
    g2.fillOval(24, 74, 30, 30);
    g2.fillOval(74, 74, 30, 30);
    g2 = (Graphics2D)bi[4].getGraphics();
    g2.setColor(Color.lightGray);
    g2.fillRect(0, 0, 128, 128);
    g2.setColor(Color.black);
    g2.fillOval(14, 14, 30, 30);
    g2.fillOval(49, 49, 30, 30);
    g2.fillOval(84, 84, 30, 30);
    g2.fillOval(14, 84, 30, 30);
    g2.fillOval(84, 14, 30, 30);
    g2 = (Graphics2D)bi[5].getGraphics();
    g2.setColor(Color.lightGray);
    g2.fillRect(0, 0, 128, 128);
    g2.setColor(Color.black);
    g2.fillOval(14, 14, 30, 30);
    g2.fillOval(14, 49, 30, 30);
    g2.fillOval(14, 84, 30, 30);
    g2.fillOval(84, 84, 30, 30);
    g2.fillOval(84, 49, 30, 30);
    g2.fillOval(84, 14, 30, 30);
    ImageComponent2D[] image = new ImageComponent2D[6];
    for (int i = 0; i < 6; i++) {
        image[i] = new ImageComponent2D(ImageComponent2D.FORMAT_RGBA, bi[i]);
    }
    TextureCubeMap texture = new TextureCubeMap(Texture.BASE_LEVEL, Texture.RGBA,
    image[0].getWidth());
    texture.setImage(0, TextureCubeMap.NEGATIVE_X, image[0]);
    texture.setImage(0, TextureCubeMap.NEGATIVE_Y, image[1]);
    texture.setImage(0, TextureCubeMap.NEGATIVE_Z, image[2]);
    texture.setImage(0, TextureCubeMap.POSITIVE_X, image[5]);
    texture.setImage(0, TextureCubeMap.POSITIVE_Y, image[4]);
    texture.setImage(0, TextureCubeMap.POSITIVE_Z, image[3]);
    texture.setEnable(true);
    texture.setMagFilter(Texture.BASE_LEVEL_LINEAR);
    texture.setMinFilter(Texture.BASE_LEVEL_LINEAR);
    ap.setTexture(texture);
    // texture coordinates
    TexCoordGeneration tcg = new TexCoordGeneration(TexCoordGeneration.OBJECT_LINEAR, 
    TexCoordGeneration.TEXTURE_COORDINATE_3);
    tcg.setPlaneR(new Vector4f(0, 0, 1, 0));
    ap.setTexCoordGeneration(tcg);
    return ap;
  }
}