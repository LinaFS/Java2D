
package chapter10;

import java.util.*;
import javax.media.j3d.*;

public class ClockBehavior extends Behavior {
  Text3D text;
  
  public ClockBehavior(Text3D text) {
    this.text = text;
  }
  
  public void initialize() {
    wakeupOn(new WakeupOnElapsedTime(500));
  }
  
  public void processStimulus(java.util.Enumeration enumeration) {
    int hour = Calendar.getInstance().get(Calendar.HOUR);
    int min = Calendar.getInstance().get(Calendar.MINUTE);
    int sec = Calendar.getInstance().get(Calendar.SECOND);
    text.setString(hour+":"+min+":"+sec);
    wakeupOn(new WakeupOnElapsedTime(500));
  }
}
