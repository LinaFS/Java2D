
package chapter6;

import java.awt.*;
import java.applet.*;
import java.awt.event.*;
import javax.media.j3d.*;
import javax.vecmath.*;
import com.sun.j3d.utils.universe.*;
import com.sun.j3d.utils.geometry.*;
import com.sun.j3d.utils.applet.MainFrame;

public class Ex14 extends Applet {
    public static void main(String[] args) {
        new MainFrame(new Ex14(), 640, 480);
    }
    
    public void init() {
        GraphicsConfiguration gc = SimpleUniverse.getPreferredConfiguration();
        Canvas3D cv = new Canvas3D(gc);
        setLayout(new BorderLayout());
        add(cv, BorderLayout.CENTER);
        BranchGroup bg = createSceneGraph();
        bg.compile();
        SimpleUniverse su = new SimpleUniverse(cv);
        su.getViewingPlatform().setNominalViewingTransform();
        su.addBranchGraph(bg);
    }
    
    private BranchGroup createSceneGraph() {
        BranchGroup root = new BranchGroup();
        TransformGroup spin = new TransformGroup();
        spin.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
        root.addChild(spin);
        //object
        Appearance ap = new Appearance();
        ap.setMaterial(new Material());
        PolygonAttributes pa = new PolygonAttributes();
        pa.setBackFaceNormalFlip(true);
        pa.setCullFace(PolygonAttributes.CULL_NONE);
        ap.setPolygonAttributes(pa);
        Shape3D shape = new Shape3D(mobius(),ap);
        //transformation
        Transform3D tr = new Transform3D();
        tr.setScale(0.4);
        TransformGroup tg = new TransformGroup(tr);
        spin.addChild(tg);
        tg.addChild(shape);
        Alpha alpha = new Alpha(-1, 10000);
        RotationInterpolator rotator = new RotationInterpolator(alpha, spin);
        BoundingSphere bounds = new BoundingSphere();
        bounds.setRadius(100);
        rotator.setSchedulingBounds(bounds);
        spin.addChild(rotator);
        //light
        PointLight light = new PointLight(new Color3f(Color.white),
        new Point3f(0.5f,0.5f,1f),
        new Point3f(1f,0.2f,0f));
        light.setInfluencingBounds(bounds);
        root.addChild(light);
        //background
        Background background = new Background(1.0f, 1.0f, 1.0f);
        background.setApplicationBounds(bounds);
        root.addChild(background);
        return root;
    }
       
    private Geometry mobius() {
        int m = 100;
        int n = 30;
        float vmin = -0.3f;
        float vmax = 0.3f;
        float umin = 0.0f;
        float umax = (float) (2*Math.PI);
        float du = (umax-umin)/m;
        float dv = (vmax-vmin)/n;
        
        Point3f[] verts = new Point3f[(m+1)*(n+1)];
        Vector3f[] norms = new Vector3f[(m+1)*(n+1)];
        int count = 0;
        // vertices
        float u = umin;
        for (int i = 0; i <= m; i++) {
            float v = vmin;
            for (int j = 0; j <= n; j++) {
                float x = (float) (Math.cos(u) + v*Math.cos(u/2)*Math.cos(u));
                float y = (float) (Math.sin(u) + v*Math.cos(u/2)*Math.sin(u));
                float z = (float) (v*Math.sin(u/2));
                verts[count] = new Point3f(x, y, z);
                
                float nx = (float)((1+v*Math.cos(u/2))*Math.cos(u)*Math.sin(u/2)
                -0.5*v*Math.sin(u));
                float ny = (float)((1+v*Math.cos(u/2))*Math.sin(u)*Math.sin(u/2)
                -0.5*v*Math.cos(u));
                float nz = -(float)((1+v*Math.cos(u/2))*Math.cos(u/2));
                norms[count] = new Vector3f(nx, ny, nz);
                norms[count].normalize();
                
                count++;
                v += dv;
            }
            u += du;
        }
        // indices
        int[] inds = new int[4*m*n];
        count = 0;
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                inds[count++] = i*(n+1) + j;
                inds[count++] = (i+1)*(n+1) + j;
                inds[count++] = (i+1)*(n+1) + j+1;
                inds[count++] = i*(n+1) + j+1;
            }
        }
        
        IndexedQuadArray iqa = new IndexedQuadArray((m+1)*(n+1),
        QuadArray.COORDINATES | QuadArray.NORMALS, 4*m*n);
        iqa.setCoordinates(0, verts);
        iqa.setNormals(0, norms);
        iqa.setCoordinateIndices(0, inds);
        iqa.setNormalIndices(0, inds);
        return iqa;
    }
}


