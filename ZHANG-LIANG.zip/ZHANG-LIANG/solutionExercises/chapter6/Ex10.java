package chapter6;

import java.awt.*;
import java.applet.*;
import java.awt.event.*;
import javax.media.j3d.*;
import javax.vecmath.*;
import com.sun.j3d.utils.universe.*;
import com.sun.j3d.utils.geometry.*;
import com.sun.j3d.utils.applet.MainFrame;
import javax.swing.*;

public class Ex10 extends Applet {
  public static void main(String s[]) {
    Frame frame = new Frame();
    frame.setSize(640,  480);
    Ex10 app = new Ex10();
    frame.add(app);
    frame.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent ev) {
        System.exit(0);
      } 
    });
    MenuBar mb = new MenuBar();
    frame.setMenuBar(mb);
    Menu menu = new Menu("Data");
    mb.add(menu);
    MenuItem mi = new MenuItem("Text");
    menu.add(mi);
    mi.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent ev){
        String str = JOptionPane.showInputDialog("Enter a string");
          if (str != null) Ex10.setText(str);
      } 
    });
    app.init();
    frame.setVisible(true);
  }
  
  static Text2D text;
  
  public static void setText(String str) {
    text.setString(str);
  }
  
  public void init() {
    GraphicsConfiguration gc = SimpleUniverse.getPreferredConfiguration();
    Canvas3D cv = new Canvas3D(gc);
    setLayout(new BorderLayout());
    add(cv, BorderLayout.CENTER);
    BranchGroup bg = createSceneGraph();
    bg.compile();
    SimpleUniverse su = new SimpleUniverse(cv);
    su.getViewingPlatform().setNominalViewingTransform();
    su.addBranchGraph(bg);
  }

  private BranchGroup createSceneGraph() {
    BranchGroup root = new BranchGroup();
    //object
    text = new Text2D("Hello 3D", new Color3f(1,1,1), "SansSerif", 256, Font.PLAIN);
    text.getAppearance().setCapability(Appearance.ALLOW_TEXTURE_WRITE);
    //transformation
    Transform3D tr = new Transform3D();
    tr.setScale(0.5);
    tr.setTranslation(new Vector3f(-0.95f, -0.2f, 0f));
    TransformGroup tg = new TransformGroup(tr);
    root.addChild(tg);
    tg.addChild(text);
    return root;
  }
}