package Main;

import java.awt.EventQueue;
import javax.swing.JFrame;
import interfaces.Paint;

public class MainProgram {
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Paint frame = new Paint();
			        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Define la operación de cierre
			        frame.setSize(850, 550);
			        frame.setVisible(true);
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		});
	}
}
