package funciones;

public interface SelectableShape {
    boolean isSelected();
    void setSelected(boolean selected);
}

