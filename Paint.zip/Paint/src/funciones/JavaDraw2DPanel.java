package funciones;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Arc2D;
import java.awt.geom.CubicCurve2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.QuadCurve2D;
import java.awt.geom.RoundRectangle2D;
import java.util.Vector;

import javax.swing.JPanel;

public class JavaDraw2DPanel extends JPanel implements MouseListener, MouseMotionListener {
    public static final long serialVersionUID = 1L;
    public Vector<Shape> shapes = new Vector<>();
    public static final int RECTANGLE = 0;
    public final static int ROUNDRECTANGLE2D = 1;
    public final static int ELLIPSE2D = 2;
    public final static int ARC2D = 3;
    public final static int LINE2D = 4;
    public final static int QUADCURVE2D = 5;
    public final static int CUBICCURVE2D = 6;
    public final static int POLYGON = 7;

    public int shapeType = RECTANGLE;
    Vector<Point> points = new Vector<>();
    int pointIndex = 0;
    Shape partialShape = null;
    Point p = null;
    
    public void selectAllShapes() {
        for (Shape shape : shapes) {
            if (shape instanceof SelectableShape) {
                ((SelectableShape) shape).setSelected(true);
            }
        }
        repaint();
    }

    public void deselectAllShapes() {
        for (Shape shape : shapes) {
            if (shape instanceof SelectableShape) {
                ((SelectableShape) shape).setSelected(false);
            }
        }
        repaint();
    }


    public JavaDraw2DPanel() {
        super();
        setBackground(Color.white);
        setPreferredSize(new Dimension(640, 480));
        addMouseListener(this);
        addMouseMotionListener(this);
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        for (Shape s : shapes) {
            g2.draw(s);
        }
    }

    public void mouseClicked(MouseEvent ev) {}

    public void mouseEntered(MouseEvent ev) {}

    public void mouseExited(MouseEvent ev) {}

    public void mousePressed(MouseEvent ev) {
        points.add(ev.getPoint());
        pointIndex++;
        p = null;
    }

    public void mouseReleased(MouseEvent ev) {
        Point p1 = points.get(pointIndex - 1);
        p = ev.getPoint();
        int x = Math.min(p1.x, p.x);
        int y = Math.min(p1.y, p.y);
        int width = Math.abs(p.x - p1.x);
        int height = Math.abs(p.y - p1.y);
        Shape s = null;
        switch (shapeType) {
            case RECTANGLE:
                s = new Rectangle(x, y, width, height);
                break;
            case ROUNDRECTANGLE2D:
                s = new RoundRectangle2D.Float(x, y, width, height, 10, 10);
                break;
            case ELLIPSE2D:
                s = new Ellipse2D.Float(x, y, width, height);
                break;
            case ARC2D:
                s = new Arc2D.Float(x, y, width, height, 30, 120, Arc2D.OPEN);
                break;
            case LINE2D:
                s = new Line2D.Float(p1.x, p1.y, p.x, p.y);
                break;
            case QUADCURVE2D:
                if (pointIndex > 1) {
                    Point p2 = points.get(0);
                    s = new QuadCurve2D.Float(p2.x, p2.y, p1.x, p1.y, p.x, p.y);
                }
                break;
            case CUBICCURVE2D:
                if (pointIndex > 2) {
                    Point p2 = points.get(pointIndex - 2);
                    Point p3 = points.get(pointIndex - 3);
                    s = new CubicCurve2D.Float(p3.x, p3.y, p2.x, p2.y, p1.x, p1.y, p.x, p.y);
                }
                break;
            case POLYGON:
                if (ev.isShiftDown()) {
                    s = new Polygon();
                    for (int i = 0; i < pointIndex; i++)
                        ((Polygon) s).addPoint(points.get(i).x, points.get(i).y);
                    ((Polygon) s).addPoint(p.x, p.y);
                }
                break;
        }
        if (s != null) {
            shapes.add(s);
            points.clear();
            pointIndex = 0;
            p = null;
            repaint();
        }
    }


    public void mouseMoved(MouseEvent ev) {}

    public void mouseDragged(MouseEvent ev) {
        Graphics2D g = (Graphics2D) getGraphics();
        g.setXORMode(Color.white);
        Point p1 = points.get(pointIndex - 1);
        switch (shapeType) {
            case RECTANGLE:
                if (p != null) g.drawRect(p1.x, p1.y, p.x - p1.x, p.y - p1.y);
                p = ev.getPoint();
                g.drawRect(p1.x, p1.y, p.x - p1.x, p.y - p1.y);
                break;
            case ROUNDRECTANGLE2D:
                if (p != null) g.drawRoundRect(p1.x, p1.y, p.x - p1.x, p.y - p1.y, 10, 10);
                p = ev.getPoint();
                g.drawRoundRect(p1.x, p1.y, p.x - p1.x, p.y - p1.y, 10, 10);
                break;
            case ELLIPSE2D:
                if (p != null) g.drawOval(p1.x, p1.y, p.x - p1.x, p.y - p1.y);
                p = ev.getPoint();
                g.drawOval(p1.x, p1.y, p.x - p1.x, p.y - p1.y);
                break;
            case ARC2D:
                if (p != null) g.drawArc(p1.x, p1.y, p.x - p1.x, p.y - p1.y, 30, 120);
                p = ev.getPoint();
                g.drawArc(p1.x, p1.y, p.x - p1.x, p.y - p1.y, 30, 120);
                break;
            case LINE2D:
            case POLYGON:
                if (p != null) g.drawLine(p1.x, p1.y, p.x, p.y);
                p = ev.getPoint();
                g.drawLine(p1.x, p1.y, p.x, p.y);
                break;
            case QUADCURVE2D:
                if (pointIndex == 1) {
                    if (p != null) g.drawLine(p1.x, p1.y, p.x, p.y);
                    p = ev.getPoint();
                    g.drawLine(p1.x, p1.y, p.x, p.y);
                } else {
                    Point p2 = points.get(pointIndex - 2);
                    if (p != null) g.draw(partialShape);
                    p = ev.getPoint();
                    partialShape = new QuadCurve2D.Float(p2.x, p2.y, p1.x, p1.y, p.x, p.y);
                    g.draw(partialShape);
                }
                break;
            case CUBICCURVE2D:
                if (pointIndex == 1) {
                    if (p != null) g.drawLine(p1.x, p1.y, p.x, p.y);
                    p = ev.getPoint();
                    g.drawLine(p1.x, p1.y, p.x, p.y);
                } else if (pointIndex == 2) {
                    Point p2 = points.get(pointIndex - 2);
                    if (p != null) g.draw(partialShape);
                    p = ev.getPoint();
                    partialShape = new QuadCurve2D.Float(p2.x, p2.y, p1.x, p1.y, p.x, p.y);
                    g.draw(partialShape);
                } else {
                    Point p2 = points.get(pointIndex - 2);
                    Point p3 = points.get(pointIndex - 3);
                    if (p != null) g.draw(partialShape);
                    p = ev.getPoint();
                    partialShape = new CubicCurve2D.Float(p3.x, p3.y, p2.x, p2.y, p1.x, p1.y, p.x, p.y);
                    g.draw(partialShape);
                }
                break;
        }
    }
    
    
}