/**
 * 
 */
/**
 * 
 */
module Paint {
	requires java.desktop;
}