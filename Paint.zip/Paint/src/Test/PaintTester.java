package Test;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class PaintTester extends JFrame {
    private int lastX, lastY;
    private Color currentColor = Color.BLACK;

    public PaintTester() {
        setTitle("Paint Simulator");
        setSize(800, 600);

        JPanel canvas = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(currentColor);
            }
        };

        canvas.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                lastX = e.getX();
                lastY = e.getY();
            }
        });

        canvas.addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent e) {
                Graphics g = canvas.getGraphics();
                g.setColor(currentColor);
                int x = e.getX();
                int y = e.getY();
                g.drawLine(lastX, lastY, x, y);
                lastX = x;
                lastY = y;
            }
        });

        JPanel colorPanel = new JPanel();
        colorPanel.setPreferredSize(new Dimension(50, 100));
        colorPanel.setBackground(Color.WHITE);

        JButton colorButton = new JButton("Change Color");
        colorButton.addActionListener(e -> {
            Color newColor = JColorChooser.showDialog(null, "Choose a color", currentColor);
            if (newColor != null) {
                currentColor = newColor;
                colorPanel.setBackground(currentColor);
            }
        });

        getContentPane().add(canvas, BorderLayout.CENTER);
        getContentPane().add(colorPanel, BorderLayout.EAST);
        getContentPane().add(colorButton, BorderLayout.SOUTH);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(PaintTester::new);
    }
}
