package Test;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class PaintSimulator extends JFrame {
    private int lastX, lastY;
    private int shapeWidth, shapeHeight;
    private Color currentColor = Color.BLACK;
    private boolean eraseMode = false;
    private enum ShapeType {LINE, RECTANGLE, CIRCLE};
    private ShapeType currentShape = ShapeType.LINE;

    public PaintSimulator() {
        setTitle("Paint Simulator");
        setSize(800, 600);

        JPanel canvas = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(currentColor);
                switch (currentShape) {
                    case LINE:
                        g.drawLine(lastX, lastY, shapeWidth, shapeHeight);
                        break;
                    case RECTANGLE:
                        g.drawRect(lastX, lastY, shapeWidth, shapeHeight);
                        break;
                    case CIRCLE:
                        g.drawOval(lastX, lastY, shapeWidth, shapeHeight);
                        break;
                }
            }
        };

        canvas.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                lastX = e.getX();
                lastY = e.getY();
            }

            public void mouseReleased(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();
                shapeWidth = x - lastX;
                shapeHeight = y - lastY;
                canvas.repaint();
            }
        });

        JPanel shapePanel = new JPanel();
        shapePanel.setPreferredSize(new Dimension(50, 100));

        JButton lineButton = new JButton("Line");
        lineButton.addActionListener(e -> {
            currentShape = ShapeType.LINE;
        });

        JButton rectangleButton = new JButton("Rectangle");
        rectangleButton.addActionListener(e -> {
            currentShape = ShapeType.RECTANGLE;
        });

        JButton circleButton = new JButton("Circle");
        circleButton.addActionListener(e -> {
            currentShape = ShapeType.CIRCLE;
        });

        JPanel colorPanel = new JPanel();
        colorPanel.setPreferredSize(new Dimension(50, 100));
        colorPanel.setBackground(Color.WHITE);

        JButton colorButton = new JButton("Change Color");
        colorButton.addActionListener(e -> {
            Color newColor = JColorChooser.showDialog(null, "Choose a color", currentColor);
            if (newColor != null) {
                currentColor = newColor;
                colorPanel.setBackground(currentColor);
            }
        });

        JButton eraseButton = new JButton("Eraser");
        eraseButton.addActionListener(e -> {
            eraseMode = !eraseMode;
            if (eraseMode) {
                canvas.setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));
            } else {
                canvas.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            }
        });

        shapePanel.add(lineButton);
        shapePanel.add(rectangleButton);
        shapePanel.add(circleButton);

        getContentPane().add(canvas, BorderLayout.CENTER);
        getContentPane().add(shapePanel, BorderLayout.WEST);
        getContentPane().add(colorPanel, BorderLayout.EAST);
        getContentPane().add(colorButton, BorderLayout.SOUTH);
        getContentPane().add(eraseButton, BorderLayout.NORTH);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(PaintSimulator::new);
    }
}
