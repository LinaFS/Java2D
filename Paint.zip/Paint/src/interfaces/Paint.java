package interfaces;

import javax.swing.*;
import java.awt.geom.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.*;
import java.util.Vector;

import funciones.SelectableShape;
import funciones.JavaDraw2DPanel;

public class Paint extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
	private JavaDraw2DPanel panel;

    public Paint() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 878, 639);
        contentPane = new JPanel();
        contentPane.setBorder(new LineBorder(new Color(0, 0, 0)));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        panel = new JavaDraw2DPanel();
        panel.setBounds(3, 44, 878, 639); // Establece los límites del panel para que ocupe todo el área del contentPane
        contentPane.add(panel);

        JMenuBar menuBar = new JMenuBar();
        menuBar.setBounds(87, 0, 756, 38);
        contentPane.add(menuBar);

        JMenu mnNewMenu = new JMenu("Figuras");
        menuBar.add(mnNewMenu);
        mnNewMenu.setHorizontalAlignment(SwingConstants.CENTER);
        JMenuItem mi = new JMenuItem("Rectangle");
        mi.addActionListener(this);
        mnNewMenu.add(mi);
        mi = new JMenuItem("RoundRectangle");
        mi.addActionListener(this);
        mnNewMenu.add(mi);
        mi = new JMenuItem("Oval");
        mi.addActionListener(this);
        mnNewMenu.add(mi);
        mi = new JMenuItem("Line");
        mi.addActionListener(this);
        mnNewMenu.add(mi);
        mi = new JMenuItem("Arc");
        mi.addActionListener(this);
        mnNewMenu.add(mi);
        mi = new JMenuItem("Polygon");
        mi.addActionListener(this);
        mnNewMenu.add(mi);
        mi = new JMenuItem("QuadCurve");
        mi.addActionListener(this);
        mnNewMenu.add(mi);
        mi = new JMenuItem("CubicCurve");
        mi.addActionListener(this);
        mnNewMenu.add(mi);

        JMenu mnNewMenu_1 = new JMenu("Herramientas");
        menuBar.add(mnNewMenu_1);
        mnNewMenu_1.setHorizontalAlignment(SwingConstants.CENTER);

        JButton btnNewButton = new JButton("Selección");
        btnNewButton.setBounds(3, 0, 85, 38);
        contentPane.add(btnNewButton);
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                panel.selectAllShapes();
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        if ("Rectangle".equals(command)) {
            panel.shapeType = JavaDraw2DPanel.RECTANGLE;
        } else if ("RoundRectangle".equals(command)) {
            panel.shapeType = JavaDraw2DPanel.ROUNDRECTANGLE2D;
        } else if ("Oval".equals(command)) {
            panel.shapeType = JavaDraw2DPanel.ELLIPSE2D;
        } else if ("Arc".equals(command)) {
            panel.shapeType = JavaDraw2DPanel.ARC2D;
        } else if ("Line".equals(command)) {
            panel.shapeType = JavaDraw2DPanel.LINE2D;
        } else if ("QuadCurve".equals(command)) {
            panel.shapeType = JavaDraw2DPanel.QUADCURVE2D;
        } else if ("CubicCurve".equals(command)) {
            panel.shapeType = JavaDraw2DPanel.CUBICCURVE2D;
        } else if ("Polygon".equals(command)) {
            panel.shapeType = JavaDraw2DPanel.POLYGON;
        }
    }
}


